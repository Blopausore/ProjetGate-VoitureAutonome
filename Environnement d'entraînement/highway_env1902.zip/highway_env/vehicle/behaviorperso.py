
import gym
import highway_env
from stable_baselines3 import PPO
from typing import Tuple, Union

import numpy as np

from highway_env.road.road import Road, Route, LaneIndex
from highway_env.utils import Vector
from highway_env.vehicle.controller import ControlledVehicle
from highway_env import utils
from highway_env.vehicle.kinematics import Vehicle





class EnemyVehicle(ControlledVehicle):
    model = PPO.load("racetrack_coursernd_ppo16200/model")

    def observe(self,n):
        orient =self.heading
        dist = self.trace(self.position, self.velocity)[1]
        
        #if self.normalize:
         #   reference /= self.maximum_range
        #print(orient)
        for i in range(len(dist)):
            if dist[i][0][1] - dist[i][0][0] > 1.5 * np.pi:
                dist[i][0][0] , dist[i][0][1] = dist[i][0][1] -2*np.pi, dist[i][0][0] +2*np.pi
                #print("cc"+ str(i))
        
        #print(reference)
        #print(dist)
        #print(orient, reference)
        alpha= orient #np.arctan(orient[1]/orient[0])
        
        espacement= np.pi/n
        crash=0
        affich = []
        listang= [orient + i*espacement - np.pi/2 for i in range(n)]
        
        for i in range(len(listang)):
            while listang[i] > np.pi:
                listang[i]-= 2*np.pi
            while listang[i] < -np.pi:
                listang[i]+= 2*np.pi
        #print(listang)
        listealpha = [ np.array([np.cos(alpha- np.pi/2 +espacement*j), np.sin(alpha - np.pi/2 + espacement*j)]) for j in range(n)]
        listepts = []
        #print(listealpha)
        
        ind1 , ind2 , _ = self.lane_index
        ind1 , ind2 = ord(ind1) -97 ,ord(ind2)  - 95
        lanelist = []
        k=0
        for w in self.road.network.graph.values():
                        for j in w.values():
                            k+=1
                            lanelist.append(j)
        #print(lanelist)
        #print(self.observer_vehicle.lane)
        visiblelane = []
        
        #print(ind2 == len(lanelist) + 2 ,ind1 ,  ind2 , len(lanelist))
        taille = len(lanelist)
        if ind2 == taille + 1 :
                    #print("oui")
                    for j in range(ind1, ind2-1):
                            visiblelane.append(lanelist[j][0])
                            visiblelane.append(lanelist[j][1])
                    visiblelane.append(lanelist[0][0])
                    visiblelane.append(lanelist[0][1])
        
        elif ind2 ==  2 or ind2 == taille + 2:
                    #print("on")
                    visiblelane.append(lanelist[ind1][0])
                    visiblelane.append(lanelist[ind1][1])
                    visiblelane.append(lanelist[0][0])
                    visiblelane.append(lanelist[0][1])
                    visiblelane.append(lanelist[1][0])
                    visiblelane.append(lanelist[1][1])
        elif ind2 == taille:
            
            for j in range(ind1, ind2):
                            for k in range(len(lanelist[j])):
                                visiblelane.append(lanelist[j][k])
        else:

                    for j in range(ind1, ind2):
                            visiblelane.append(lanelist[j][0])
                            visiblelane.append(lanelist[j][1])
        #print(visiblelane)
        minref = 1
        ind=0
        
        #print(reference)
        #print("indice =" + str(ind))
        for w in range(len(listealpha)):
            i=0
            res = True
            angle = listealpha[w]
            while res and i<30 :
                i+=1
                res = False
                for j in range(len(visiblelane)):
                    if visiblelane[j].on_lane(self.position + i*angle):
                                res=True
                                break
                
            
                #print(self.observer_vehicle.lane.on_lane(self.observer_vehicle.position + i*self.observer_vehicle.direction))
            pts = i
            #print(listang)
            
            for k in range(len(dist)):
                reference = dist[k][0]
                #print(reference)
                if reference[0]-0.2<listang[w]<reference[1]:
                    
                    #print(k, i, dist[k][1])
                    pts = min(i,dist[k][1])
              
            #print(i, dist, pts)
            #print(listang[w])
            affich.append([(0,0), pts*angle])
            #print(affich)
            if i!=0:
                crash+=1

            #center_angle = angle
            #center_index = self.angle_to_index(center_angle)
            #direction = self.index_to_direction(center_index)
            listepts.append([pts/30]) # - self.observer_vehicle.velocity.dot(direction
        #print(self.observer_vehicle.position)
        
        if crash == 0 :
            #print("oui")
            self.crashed = True

        self.grid = affich
        
        vit = np.cos(self.velocity[0]) + np.sin(self.velocity[1])
        listepts.append([vit])
        listepts.append([self.previous_heading - self.heading])
        self.previous_heading = self.heading
        return listepts
    
    def trace(self, origin: np.ndarray, origin_velocity: np.ndarray) -> np.ndarray:
        self.origin = origin.copy()
        self.grid = np.ones((32)) * 30
        #print(self.lidarview(5))
        

        angles = []
        min_angle,max_angle=0,0
        distv=[]

        distance = 50
        for obstacle in self.road.vehicles + self.road.objects :
            if obstacle is self or not obstacle.solid:
                continue
            center_distance = np.linalg.norm(obstacle.position - origin)
            if center_distance > 30:
                continue
            center_angle = self.position_to_angle(obstacle.position, origin)
            #print(center_angle)
            center_index = self.angle_to_index(center_angle)
            distance = center_distance - obstacle.WIDTH / 2
            
            if distance <= self.grid[center_index]:
                direction = self.index_to_direction(center_index)
                velocity = (obstacle.velocity - origin_velocity).dot(direction)
                self.grid[center_index] = distance

            # Angular sector covered by the obstacle
            corners = utils.rect_corners(obstacle.position, obstacle.LENGTH, obstacle.WIDTH, obstacle.heading)
            angles = [self.position_to_angle(corner, origin) for corner in corners]
            min_angle, max_angle = min(angles), max(angles)
            start, end = self.angle_to_index(min_angle), self.angle_to_index(max_angle)
            distv.append([[min_angle,max_angle],distance])
            if start < end:
                indexes = np.arange(start, end+1)
            else:
                indexes = np.hstack([np.arange(start, 32), np.arange(0, end + 1)])

            # Actual distance computation for these sections
            for index in indexes:
                direction = self.index_to_direction(index)
                ray = [origin, origin + 30 * direction]
                distance = utils.distance_to_rect(ray, corners)
                
                if distance <= self.grid[index]:
                    velocity = (obstacle.velocity - origin_velocity).dot(direction)
                    self.grid[index] = distance
        #print( angles)
        return self.grid , distv

    def position_to_angle(self, position: np.ndarray, origin: np.ndarray) -> float:
        return np.arctan2(position[1] - origin[1], position[0] - origin[0]) + 2 * np.pi /16 /2

    def position_to_index(self, position: np.ndarray, origin: np.ndarray) -> int:
        return self.angle_to_index(self.position_to_angle(position, origin))
        
    def angle_to_index(self, angle: float) -> int:
        return int(np.floor(angle / 2 * np.pi /16)) % (32)

    def index_to_direction(self, index: int) -> np.ndarray:
        return np.array([np.cos(index * 2 * np.pi /16), np.sin(index * 2 * np.pi /16)])

    def act(self):
        obs=self.observe(16)
        action, _states = self.model.predict(obs, deterministic=True)
        rep = {'steering': action[1], 'acceleration': action[0]}
        Vehicle.act(self,rep)

    ACC_MAX = 6.0  # [m/s2]
    """Maximum acceleration."""

    COMFORT_ACC_MAX = 3.0  # [m/s2]
    """Desired maximum acceleration."""

    COMFORT_ACC_MIN = -5.0  # [m/s2]
    """Desired maximum deceleration."""

    DISTANCE_WANTED = 5.0 + ControlledVehicle.LENGTH  # [m]
    """Desired jam distance to the front vehicle."""

    TIME_WANTED = 1.5  # [s]
    """Desired time gap to the front vehicle."""

    DELTA = 4.0  # []
    """Exponent of the velocity term."""

    DELTA_RANGE = [3.5, 4.5]
    """Range of delta when chosen randomly."""

    # Lateral policy parameters
    POLITENESS = 0.  # in [0, 1]
    LANE_CHANGE_MIN_ACC_GAIN = 0.2  # [m/s2]
    LANE_CHANGE_MAX_BRAKING_IMPOSED = 2.0  # [m/s2]
    LANE_CHANGE_DELAY = 1.0  # [s]

    def __init__(self,
                 road: Road,
                 position: Vector,
                 heading: float = 0,
                 speed: float = 0,
                 target_lane_index: int = None,
                 target_speed: float = None,
                 route: Route = None,
                 enable_lane_change: bool = True,
                 timer: float = None):
        super().__init__(road, position, heading, speed, target_lane_index, target_speed, route)
        self.enable_lane_change = enable_lane_change
        self.timer = timer or (np.sum(self.position)*np.pi) % self.LANE_CHANGE_DELAY

    def randomize_behavior(self):
        self.DELTA = self.road.np_random.uniform(low=self.DELTA_RANGE[0], high=self.DELTA_RANGE[1])

    @classmethod
    def create_from(cls, vehicle: ControlledVehicle) -> "EnemyVehicle":
        """
        Create a new vehicle from an existing one.

        The vehicle dynamics and target dynamics are copied, other properties are default.

        :param vehicle: a vehicle
        :return: a new vehicle at the same dynamical state
        """
        v = cls(vehicle.road, vehicle.position, heading=vehicle.heading, speed=vehicle.speed,
                target_lane_index=vehicle.target_lane_index, target_speed=vehicle.target_speed,
                route=vehicle.route, timer=getattr(vehicle, 'timer', None))
        return v


    def step(self, dt: float):
        """
        Step the simulation.

        Increases a timer used for decision policies, and step the vehicle dynamics.

        :param dt: timestep
        """
        self.timer += dt
        super().step(dt)

    def acceleration(self,
                     ego_vehicle: ControlledVehicle,
                     front_vehicle: Vehicle = None,
                     rear_vehicle: Vehicle = None) -> float:
        """
        Compute an acceleration command with the Intelligent Driver Model.

        The acceleration is chosen so as to:
        - reach a target speed;
        - maintain a minimum safety distance (and safety time) w.r.t the front vehicle.

        :param ego_vehicle: the vehicle whose desired acceleration is to be computed. It does not have to be an
                            IDM vehicle, which is why this method is a class method. This allows an IDM vehicle to
                            reason about other vehicles behaviors even though they may not IDMs.
        :param front_vehicle: the vehicle preceding the ego-vehicle
        :param rear_vehicle: the vehicle following the ego-vehicle
        :return: the acceleration command for the ego-vehicle [m/s2]
        """
        if not ego_vehicle or not isinstance(ego_vehicle, Vehicle):
            return 0
        ego_target_speed = abs(utils.not_zero(getattr(ego_vehicle, "target_speed", 0)))
        acceleration = self.COMFORT_ACC_MAX * (
                1 - np.power(max(ego_vehicle.speed, 0) / ego_target_speed, self.DELTA))

        if front_vehicle:
            d = ego_vehicle.lane_distance_to(front_vehicle)
            acceleration -= self.COMFORT_ACC_MAX * \
                np.power(self.desired_gap(ego_vehicle, front_vehicle) / utils.not_zero(d), 2)
        return acceleration

    def desired_gap(self, ego_vehicle: Vehicle, front_vehicle: Vehicle = None, projected: bool = True) -> float:
        """
        Compute the desired distance between a vehicle and its leading vehicle.

        :param ego_vehicle: the vehicle being controlled
        :param front_vehicle: its leading vehicle
        :param projected: project 2D velocities in 1D space
        :return: the desired distance between the two [m]
        """
        d0 = self.DISTANCE_WANTED
        tau = self.TIME_WANTED
        ab = -self.COMFORT_ACC_MAX * self.COMFORT_ACC_MIN
        dv = np.dot(ego_vehicle.velocity - front_vehicle.velocity, ego_vehicle.direction) if projected \
            else ego_vehicle.speed - front_vehicle.speed
        d_star = d0 + ego_vehicle.speed * tau + ego_vehicle.speed * dv / (2 * np.sqrt(ab))
        return d_star

    def change_lane_policy(self) -> None:
        """
        Decide when to change lane.

        Based on:
        - frequency;
        - closeness of the target lane;
        - MOBIL model.
        """
        # If a lane change is already ongoing
        if self.lane_index != self.target_lane_index:
            # If we are on correct route but bad lane: abort it if someone else is already changing into the same lane
            if self.lane_index[:2] == self.target_lane_index[:2]:
                for v in self.road.vehicles:
                    if v is not self \
                            and v.lane_index != self.target_lane_index \
                            and isinstance(v, ControlledVehicle) \
                            and v.target_lane_index == self.target_lane_index:
                        d = self.lane_distance_to(v)
                        d_star = self.desired_gap(self, v)
                        if 0 < d < d_star:
                            self.target_lane_index = self.lane_index
                            break
            return

        # else, at a given frequency,
        if not utils.do_every(self.LANE_CHANGE_DELAY, self.timer):
            return
        self.timer = 0

        # decide to make a lane change
        for lane_index in self.road.network.side_lanes(self.lane_index):
            # Is the candidate lane close enough?
            if not self.road.network.get_lane(lane_index).is_reachable_from(self.position):
                continue
            # Only change lane when the vehicle is moving
            if np.abs(self.speed) < 1:
                continue
            # Does the MOBIL model recommend a lane change?
            if self.mobil(lane_index):
                self.target_lane_index = lane_index

    def mobil(self, lane_index: LaneIndex) -> bool:
        """
        MOBIL lane change model: Minimizing Overall Braking Induced by a Lane change

            The vehicle should change lane only if:
            - after changing it (and/or following vehicles) can accelerate more;
            - it doesn't impose an unsafe braking on its new following vehicle.

        :param lane_index: the candidate lane for the change
        :return: whether the lane change should be performed
        """
        # Is the maneuver unsafe for the new following vehicle?
        new_preceding, new_following = self.road.neighbour_vehicles(self, lane_index)
        new_following_a = self.acceleration(ego_vehicle=new_following, front_vehicle=new_preceding)
        new_following_pred_a = self.acceleration(ego_vehicle=new_following, front_vehicle=self)
        if new_following_pred_a < -self.LANE_CHANGE_MAX_BRAKING_IMPOSED:
            return False

        # Do I have a planned route for a specific lane which is safe for me to access?
        old_preceding, old_following = self.road.neighbour_vehicles(self)
        self_pred_a = self.acceleration(ego_vehicle=self, front_vehicle=new_preceding)
        if self.route and self.route[0][2] is not None:
            # Wrong direction
            if np.sign(lane_index[2] - self.target_lane_index[2]) != np.sign(self.route[0][2] - self.target_lane_index[2]):
                return False
            # Unsafe braking required
            elif self_pred_a < -self.LANE_CHANGE_MAX_BRAKING_IMPOSED:
                return False

        # Is there an acceleration advantage for me and/or my followers to change lane?
        else:
            self_a = self.acceleration(ego_vehicle=self, front_vehicle=old_preceding)
            old_following_a = self.acceleration(ego_vehicle=old_following, front_vehicle=self)
            old_following_pred_a = self.acceleration(ego_vehicle=old_following, front_vehicle=old_preceding)
            jerk = self_pred_a - self_a + self.POLITENESS * (new_following_pred_a - new_following_a
                                                             + old_following_pred_a - old_following_a)
            if jerk < self.LANE_CHANGE_MIN_ACC_GAIN:
                return False

        # All clear, let's go!
        return True

    def recover_from_stop(self, acceleration: float) -> float:
        """
        If stopped on the wrong lane, try a reversing maneuver.

        :param acceleration: desired acceleration from IDM
        :return: suggested acceleration to recover from being stuck
        """
        stopped_speed = 5
        safe_distance = 200
        # Is the vehicle stopped on the wrong lane?
        if self.target_lane_index != self.lane_index and self.speed < stopped_speed:
            _, rear = self.road.neighbour_vehicles(self)
            _, new_rear = self.road.neighbour_vehicles(self, self.road.network.get_lane(self.target_lane_index))
            # Check for free room behind on both lanes
            if (not rear or rear.lane_distance_to(self) > safe_distance) and \
                    (not new_rear or new_rear.lane_distance_to(self) > safe_distance):
                # Reverse
                return -self.COMFORT_ACC_MAX / 2
        return acceleration


